package com.capgemini.web.ars.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import org.jboss.security.ISecurityManagement;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.service.AirlineReservationServiceImpl;
import com.capgemini.web.ars.service.IAirlineReservationService;
import com.cg.airSpace.util.DbUtil;


@WebServlet("*.do")
public class Controller extends HttpServlet {

	Connection conn = null;
	PreparedStatement pstm = null; 
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getServletPath();
		
		IAirlineReservationService servObj = new AirlineReservationServiceImpl();
		
		
		switch(action){
		
		case "/login.do":
			
			RequestDispatcher view= request.getRequestDispatcher("login.jsp");
			view.forward(request, response);
			
		break;
		
		case "/enter.do":
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
	
			try
			{
					conn = DbUtil.getConnection();
					PreparedStatement pstm=conn.prepareStatement("Select role from  users"
							+ " where username = ? and password = ? ");
					pstm.setString(1,uname);
					pstm.setString(2, pass);
					ResultSet res = pstm.executeQuery();
					
					 String roles=null;
					 
					 if(res.next())
					 {
						  roles=res.getString("role");
					 } 
					
					  if(roles==null || roles.equals(""))
					    {
					    	  
							  response.sendRedirect("login.jsp");	
					    }
				 
					  else if(roles.equals("admin")) 
						    { 
						   		ArrayList<Airport> airportList = servObj.getAirportList();
						   		
						   		request.setAttribute("role", roles);
						   		HttpSession session = request.getSession();
						   		session.setAttribute("arpList",airportList);
						    
						   		System.out.println(airportList);
						   		RequestDispatcher rd = request.getRequestDispatcher("Admin.jsp");
						   		rd.forward(request, response);
						    } 
					  else if(roles.equals("executive")) 
						    { 
						    	System.out.println(roles); 
						    	request.setAttribute("type", roles);
						    	RequestDispatcher rd = request.getRequestDispatcher("Excecutive.jsp");
						    	rd.forward(request, response);
						    } 
					  
			}
			
				 
			 catch (NamingException | SQLException e)
			{
				e.printStackTrace();
			}
			
			
			break;
		}
	}
	
}
