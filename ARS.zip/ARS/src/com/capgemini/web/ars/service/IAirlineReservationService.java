package com.capgemini.web.ars.service;

import java.sql.Date;

import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;

public interface IAirlineReservationService 
{
	public void addAirport(Airport ap);
	public void addFlightInformation(FlightInformation flightInfo);
	public int addBookingInformation(BookingInformation bookingEntry);
	public ArrayList <FlightInformation> showOnDate(Date date);
	public ArrayList<FlightInformation> viewFlightBtw(String depArp , String arrArp);
	public ArrayList<BookingInformation> viewBookings(int flightNo);
	public FlightInformation viewFlightDetail(int flightNo);
	public ArrayList<Airport> getAirportList();
	
}
