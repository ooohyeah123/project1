package com.cg.airspace;

public class User
{
	private String name;
	private String user_Name;
	private String password;
	private String mobile_Number;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String name, String user_Name, String password,
			String mobile_Number) {
		super();
		this.name = name;
		this.user_Name = user_Name;
		this.password = password;
		this.mobile_Number = mobile_Number;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", user_Name=" + user_Name
				+ ", password=" + password + ", mobile_Number=" + mobile_Number
				+ "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUser_Name() {
		return user_Name;
	}
	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobile_Number() {
		return mobile_Number;
	}
	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}
	
	
}
