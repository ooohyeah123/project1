package com.cg.airspace.service;

import com.cg.airspace.User;
import com.cg.airspace.DAO.IUserDao;
import com.cg.airspace.DAO.UserDaoImpl;
import com.cg.exception.userException;

public class UserServiceImpl implements IUserService
{

private IUserDao dao = null; 

	
	public UserServiceImpl()
	{
	   dao = new  UserDaoImpl();
	}
	
	@Override
	public int addUser(User user) throws userException {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}

	@Override
	public int generateBillId() throws userException {
		return dao.generateBillId();
	}

}
