package com.cg.airspace.service;

import com.cg.airspace.User;
import com.cg.exception.userException;

public interface IUserService
{
	int addUser(User user) throws userException;
	int generateBillId() throws userException ;
}
