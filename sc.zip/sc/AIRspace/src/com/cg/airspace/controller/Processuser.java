package com.cg.airspace.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.airspace.User;
import com.cg.airspace.service.IUserService;
import com.cg.airspace.service.UserServiceImpl;
import com.cg.exception.userException;

@WebServlet(name = "ProcessUser", urlPatterns = { "/ProcessUser" })
public class Processuser extends HttpServlet {
	
private IUserService service = null;
	
	@Override
	public void init() throws ServletException {
		service = new UserServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String action = request.getParameter("action");
		    User user = null;
		    
		    switch (action) {
			case "register":
				String name = request.getParameter("name");
				String phone = request.getParameter("phone");
				String uname = request.getParameter("uname");
				String password = request.getParameter("pass");
				
				user = new User(name, uname, password, phone);
				
				try 
				{
					service.addUser(user);
					request.getSession().setAttribute("user", user);
				}
				catch (userException e) {
					
				
					System.out.println(e.getMessage());
					request.getSession().setAttribute("error", e.getMessage());
				}
				RequestDispatcher rd = request.getRequestDispatcher("CustomerHome.jsp");
				rd.forward(request, response);
				
				
				
				break;
				
			case "payBill":
				Date billdate = new Date();
			  String amount = request.getParameter("amount");
			  int amounPaid = Integer.parseInt(amount);
			  int balanceAmount = 750 - amounPaid;
			  request.getSession().setAttribute("balanceAmount", balanceAmount);
			  request.getSession().setAttribute("billDate", billdate);
				try 
				{
					int billId = service.generateBillId();
					request.getSession().setAttribute("billId", billId );
				}
				catch (userException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				RequestDispatcher rd1 = request.getRequestDispatcher("Success.jsp");
				rd1.forward(request, response);
				break;
		    
			default:
				break;
			}
	}
		   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
