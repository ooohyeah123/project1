package com.cg.airspace.DAO;

import com.cg.airspace.User;
import com.cg.exception.userException;

public interface IUserDao 
{
	int addUser(User user) throws userException;
	int generateBillId() throws userException ;
}
