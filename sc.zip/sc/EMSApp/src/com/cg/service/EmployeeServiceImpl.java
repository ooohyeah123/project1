package com.cg.service;

import java.util.List;

import com.cg.DAO.EmployeeDAOImpl;
import com.cg.DAO.IEmployeeDAO;
import com.cg.Exception.EMSException;
import com.cg.dto.Employee;

public class EmployeeServiceImpl implements IEmployeeService
{

	IEmployeeDAO EmpDao = new EmployeeDAOImpl();
	
	@Override
	public int add(Employee e) throws EMSException 
	{
		return EmpDao.add(e);	
	}

	@Override
	public List<Employee> showAll() throws EMSException {
	
		return EmpDao.showAll();
	}

	@Override
	public void update(Employee e) throws EMSException {
		
		 EmpDao.update(e);
	}	 

	@Override
	public Employee search(int empid) throws EMSException {
					return EmpDao.search(empid);
				}
		
	}


