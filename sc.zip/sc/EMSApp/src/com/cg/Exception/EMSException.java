package com.cg.Exception;

public class EMSException extends Exception
{

	public EMSException(String string) {
		super(string);
	}

}
