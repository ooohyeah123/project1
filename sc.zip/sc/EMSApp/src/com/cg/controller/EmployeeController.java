package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.Exception.EMSException;
import com.cg.dto.Employee;
import com.cg.service.EmployeeServiceImpl;
import com.cg.service.IEmployeeService;

@WebServlet({ "/EmployeeController", "/employees" })
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EmployeeController() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String action = request.getParameter("action");
		
		IEmployeeService service = new EmployeeServiceImpl();
		
		switch(action){
		
		case "edit":
			String empid = request.getParameter("id");
			String error;
			if(empid!=null){
				try{
				int id = Integer.parseInt(empid);
				Employee e = service.search(id);
				System.out.println("Employee found: "+e.getDesignation());
				request.setAttribute("emp", e);
				RequestDispatcher view = request.getRequestDispatcher("edit.jsp");
				view.forward(request, response);
				
				}catch(EMSException ex){
					error = "Cannot search employee id "+empid;
					System.out.println("Error "+ex.getMessage());
				}
			}else{
				error="Please select employee to edit";
				response.sendRedirect("index.jsp?error="+error);						
			}
			return;
			
		case "update":
			Employee e = new Employee();
			e.setName(request.getParameter("name"));
			e.setDesignation(request.getParameter("designation"));
			e.setGender(request.getParameter("gender"));
			e.setPhone(request.getParameter("phone"));
			e.setEmail(request.getParameter("email"));
			String str = request.getParameter("empid");
			e.setEmpId(Integer.parseInt(str));
			try{
			service.update(e);
				request.setAttribute("message", "Record updated!");
			}catch(EMSException ex){
				request.setAttribute("error", "Unable to update, "+ex.getMessage());
			}
			RequestDispatcher view = request.getRequestDispatcher("index.jsp");
			view.forward(request, response);
			
			return;
			
		case "list":
			
		//	RequestDispatcher view = request.getRequestDispatcher("list.jsp");
			
			try 
			{	
				//code to list employees
				List<Employee> emps=service.showAll();
				//add list into session
				request.getSession().setAttribute("emplist", emps);
				//forward request to "list.jsp"	
			}
			catch (EMSException e1) {
				e1.printStackTrace();
				request.getSession().setAttribute("error", e1.getMessage());
			}
			RequestDispatcher view1 = request.getRequestDispatcher("list.jsp");
			view1.forward(request, response);
			return;
			
		case "add":
			//code to add employee
			Employee e2 = new Employee();
			e2.setName(request.getParameter("name"));
			e2.setEmail(request.getParameter("email"));
			e2.setDesignation(request.getParameter("designation"));
			e2.setPhone(request.getParameter("phone"));
			e2.setGender(request.getParameter("gender"));
			//save using service
			try 
			{
				int Id =	service.add(e2);
				e2.setEmpId(Id);
			}
			catch (EMSException ex)
			{
				request.getSession().setAttribute("error", ex.getMessage());
				ex.printStackTrace();
			}
			
			request.getSession().setAttribute("emp", e2);
			//store error/success message in session
			RequestDispatcher view2 = request.getRequestDispatcher("success.jsp");
			view2.forward(request, response);
			//forward rquest to successs.jsp
			return;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);	
	}

}
