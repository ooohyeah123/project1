package com.cg.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;

import com.cg.Exception.EMSException;
import com.cg.Util.DbUtil;
import com.cg.dto.Employee;

public class EmployeeDAOImpl implements IEmployeeDAO
{

	private static final String INSERT_QUERY = "INSERT into emp2(empId,name,email,designation"
			+ ",phone,gender)"
			+ "values(emp_seq2.nextval,?,?,?,?,?)";
	
	private static final String GET_ALL_QUERY="SELECT empId,name,email,designation,phone,gender FROM emp2";
	
	private static final String UPDATE_QUERY="update emp2 set name=?, email=?"
			+ "designation=?,phone=?,gender=? where empId=?";
	
	private static final String SELECT_QUERY=
			"select empid,ename,gender,designation,phone,email from emp2 where empid=?";
	
//	private static final String SELECT_QUERY=
	@Override
	public int add(Employee e) throws EMSException 
	{
		Connection conn;
		try {
			conn = DbUtil.getConnection();
			
			PreparedStatement ps = conn.prepareStatement(INSERT_QUERY);
			ps.setString(1,e.getName());
			ps.setString(2,e.getEmail());
			ps.setString(3,e.getDesignation());
			ps.setString(4,e.getPhone());
			ps.setString(5,e.getGender());
			ps.executeUpdate();
			
		//	ResultSet set = ps.getGeneratedKeys();
			int Id = 0;
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select emp_seq2.currval from dual");
			if(rs.next())
			{
				Id= rs.getInt(1);
				System.out.println("Seq value" +Id);	
			}
			
			conn.close();
			return Id;
			
		} 
		
		catch (NamingException | SQLException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw new EMSException("Unable to save, " +e1.getMessage());
		}
	}

	@Override
	public List<Employee> showAll() throws EMSException {
		Connection conn;
		try
		{
			conn = DbUtil.getConnection();
			PreparedStatement ps = conn.prepareStatement(GET_ALL_QUERY);
			ResultSet rs = ps.executeQuery();
			
			List<Employee> emps = new LinkedList<>();
			
			while(rs.next()){
				
				Employee e = new Employee();
				
				e.setEmpId(rs.getInt("empId"));
				e.setName(rs.getString("name"));
				e.setEmail(rs.getString("email"));
				e.setDesignation(rs.getString("designation"));
				e.setPhone(rs.getString("phone"));
				e.setGender(rs.getString("gender"));
				
			emps.add(e);
		} 
		conn.close();

		return emps;
		}
		
		catch (NamingException | SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EMSException("unable to fetch record" +e.getMessage());
		}
		
		
	}

	@Override
	public void update(Employee e) throws EMSException {
		
		Connection conn;
		try {
			conn = DbUtil.getConnection();
			PreparedStatement ps = conn.prepareStatement(UPDATE_QUERY);
			ps.setString(1,e.getName());
			ps.setString(2,e.getEmail());
			ps.setString(3,e.getDesignation());
			ps.setString(4,e.getPhone());
			ps.setString(5,e.getGender());
			ps.executeUpdate();
			
			conn.close();
		}
		catch (NamingException | SQLException e1)
		{
			e1.printStackTrace();
			throw new EMSException("Unable to update" +e1.getMessage());
			
		}
		
	
	}

	
	
	@Override
	public Employee search(int empId) throws EMSException
	{
		try{
			Connection con = DbUtil.getConnection();
			PreparedStatement ps = con.prepareStatement(SELECT_QUERY);
			ps.setInt(1, empId);
			
			ResultSet rs = ps.executeQuery();
			Employee e = new Employee();
			
			//Get ONE record at a time
			if(rs.next()){
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setEmpId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setGender(rs.getString(3));
				e.setDesignation(rs.getString(4));
				e.setPhone(rs.getString(5));
				e.setEmail(rs.getString(6));

			}
			con.close();
			//return LIST
			return e; //return object to service
		}catch(NamingException | SQLException ex){
			throw new EMSException("Unable to fetch records, "+ex.getMessage());
		
	}
	}
}
