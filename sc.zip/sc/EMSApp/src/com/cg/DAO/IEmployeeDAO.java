package com.cg.DAO;

import java.util.List;

import com.cg.Exception.EMSException;
import com.cg.dto.Employee;

public interface IEmployeeDAO {

	int add(Employee e) throws EMSException;
	
	List<Employee> showAll() throws EMSException;
	
	 void update(Employee e) throws EMSException;
	 
	 Employee search(int empId) throws EMSException;
}
