package com.cg.exception;

public class EMSException extends Exception {

	public EMSException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EMSException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
