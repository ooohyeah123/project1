package com.cg.dao;

import java.util.List;

import com.cg.beans.Employee;
import com.cg.exception.EMSException;

public interface IEmployeeDAO {
int add(Employee e) throws EMSException;
	
	List<Employee> getAll() throws EMSException;
	
	void update(Employee e) throws EMSException;

	Employee search(int empId)throws EMSException;

}
